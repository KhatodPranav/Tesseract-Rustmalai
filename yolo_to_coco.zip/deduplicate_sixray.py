"""
SIXRay Dataset Deduplication Script
====================================
Removes redundancy from the sixray_v3 dataset by:
  1. Keeping only ONE augmented version per source image within each split.
  2. Resolving cross-split leakage: if the same source image appears in
     train AND valid/test, the extra copies are removed from valid/test
     (train takes priority; valid takes priority over test).

Files (image + matching label .txt) are MOVED to a "removed/" folder
rather than deleted, so you can inspect or restore them.

Output:
  - Prints a detailed report of what was kept/removed.
  - Creates  archive (1)/sixray_v3/removed/  with discarded files.
"""

import os
import re
import shutil
from collections import defaultdict
from pathlib import Path

BASE_DIR = Path(r"C:\Users\Mayank\Downloads\archive (1)\sixray_v3")
SPLITS   = ["train", "valid", "test"]
REMOVED_DIR = BASE_DIR / "removed"

# Regex to extract source image ID from filename like
# P00001_jpg.rf.4fef5393805b235ccc02900ed63dd7d3.jpg
PATTERN = re.compile(r"^(P\d+)_jpg\.rf\.[a-f0-9]+\.jpg$", re.IGNORECASE)


def collect_images(split: str) -> dict:
    """Return {source_id: [Path, ...]} for all images in a split."""
    img_dir = BASE_DIR / split / "images"
    groups: dict = defaultdict(list)
    for f in sorted(img_dir.iterdir()):
        m = PATTERN.match(f.name)
        if m:
            groups[m.group(1)].append(f)
        else:
            print(f"  [WARN] Unrecognised filename pattern, skipping: {f.name}")
    return dict(groups)


def label_path(image_path: Path) -> Path:
    """Return the corresponding label .txt path for an image."""
    return image_path.parent.parent / "labels" / (image_path.stem + ".txt")


def move_file(src: Path, reason: str):
    """Move src (and its label) to REMOVED_DIR, preserving relative structure."""
    rel = src.relative_to(BASE_DIR)
    dst = REMOVED_DIR / rel
    dst.parent.mkdir(parents=True, exist_ok=True)
    shutil.move(str(src), str(dst))
    print(f"  [REMOVE] {rel}  ({reason})")

    lbl = label_path(src)
    if lbl.exists():
        rel_lbl = lbl.relative_to(BASE_DIR)
        dst_lbl = REMOVED_DIR / rel_lbl
        dst_lbl.parent.mkdir(parents=True, exist_ok=True)
        shutil.move(str(lbl), str(dst_lbl))
        print(f"  [REMOVE] {rel_lbl}  ({reason})")


def main():
    REMOVED_DIR.mkdir(exist_ok=True)

    # ── Step 1: collect all groups per split ──────────────────────────────────
    split_groups: dict[str, dict] = {}
    print("=" * 60)
    print("SIXRay Deduplication Report")
    print("=" * 60)
    for split in SPLITS:
        groups = collect_images(split)
        split_groups[split] = groups
        total_imgs  = sum(len(v) for v in groups.values())
        dupe_groups = {k: v for k, v in groups.items() if len(v) > 1}
        print(f"\n[{split.upper()}]  {total_imgs} images  |  {len(groups)} unique source IDs  |  {len(dupe_groups)} source IDs with >1 augmented copy")

    # ── Step 2: cross-split leakage check ─────────────────────────────────────
    print("\n" + "-" * 60)
    print("Cross-split leakage (same source ID in multiple splits):")
    all_source_ids: dict[str, str] = {}   # source_id -> first seen split (priority order)
    leakage_count = 0
    for split in SPLITS:                  # train > valid > test priority
        for src_id, files in split_groups[split].items():
            if src_id in all_source_ids:
                owner = all_source_ids[src_id]
                print(f"  {src_id}: in '{owner}' (keep) AND '{split}' (remove)")
                for f in files:
                    move_file(f, reason=f"cross-split duplicate of {owner}/{src_id}")
                split_groups[split].pop(src_id)
                leakage_count += 1
            else:
                all_source_ids[src_id] = split

    if leakage_count == 0:
        print("  None found.")

    # ── Step 3: within-split deduplication (keep first alphabetically) ────────
    print("\n" + "-" * 60)
    print("Within-split deduplication (keeping 1 augmented copy per source):")
    within_removed = 0
    for split in SPLITS:
        for src_id, files in split_groups[split].items():
            if len(files) > 1:
                keep = files[0]          # already sorted alphabetically
                for extra in files[1:]:
                    move_file(extra, reason=f"duplicate aug of {src_id} in {split}")
                    within_removed += 1

    if within_removed == 0:
        print("  No within-split duplicates found.")

    # ── Step 4: final counts ──────────────────────────────────────────────────
    print("\n" + "=" * 60)
    print("Final image counts after deduplication:")
    total_kept = 0
    for split in SPLITS:
        img_dir = BASE_DIR / split / "images"
        kept = len(list(img_dir.glob("*.jpg")))
        total_kept += kept
        print(f"  {split:6s}: {kept} images")
    print(f"  {'TOTAL':6s}: {total_kept} images")
    print(f"\nRemoved files are in: {REMOVED_DIR}")
    print("=" * 60)


if __name__ == "__main__":
    main()

