"""
SIXRay Dataset Preprocessing Script
=====================================
Applies three steps to every image in train/valid/test:

  1. NOISE REDUCTION
     Bilateral filter — smooths salt-and-pepper / Gaussian noise while
     preserving hard object edges.

  2. BACKGROUND REMOVAL
     Otsu thresholding on the grayscale channel produces a binary mask.
     Morphological closing fills small holes; the largest connected
     component is kept as the "bag" foreground. All background pixels
     are set to 0 (black).

  3. REDUCE CONTRAST ENHANCEMENT
     The source images were processed with adaptive histogram equalization
     (CLAHE), which can over-sharpen. A mild gamma correction (γ > 1)
     gently rolls back the brightness boost, yielding more natural contrast.

Originals are backed up to sixray_v3/originals_backup/ before any edits.
"""

import cv2
import numpy as np
import shutil
from pathlib import Path

BASE_DIR    = Path(r"C:\Users\Mayank\Downloads\archive (1)\sixray_v3")
SPLITS      = ["train", "valid", "test"]
BACKUP_DIR  = BASE_DIR / "originals_backup"

# ── Tunable parameters ────────────────────────────────────────────────────────
BILATERAL_D         = 9      # neighbourhood diameter for bilateral filter
BILATERAL_SIGMA_COLOR = 75   # sigma in colour space
BILATERAL_SIGMA_SPACE = 75   # sigma in coordinate space
GAMMA               = 1.25   # >1 darkens (reduces the CLAHE over-brightness)
MORPH_KERNEL_SIZE   = 15     # kernel for morphological closing in BG removal
# ─────────────────────────────────────────────────────────────────────────────


def build_gamma_lut(gamma: float) -> np.ndarray:
    """Pre-compute an 8-bit gamma lookup table."""
    inv = 1.0 / gamma
    table = np.array([(i / 255.0) ** inv * 255 for i in range(256)],
                     dtype=np.uint8)
    return table


GAMMA_LUT = build_gamma_lut(GAMMA)


def remove_background(img_bgr: np.ndarray) -> np.ndarray:
    """
    Zero-out scanner background pixels using Otsu thresholding.
    Works on the grayscale version; applies result to all 3 channels.
    """
    gray = cv2.cvtColor(img_bgr, cv2.COLOR_BGR2GRAY)

    # Otsu threshold — automatically finds the best cut between
    # bright background and darker bag/objects in an X-ray scan.
    _, mask = cv2.threshold(gray, 0, 255,
                            cv2.THRESH_BINARY_INV + cv2.THRESH_OTSU)

    # Morphological closing: fill small holes inside objects
    kernel = cv2.getStructuringElement(
        cv2.MORPH_ELLIPSE, (MORPH_KERNEL_SIZE, MORPH_KERNEL_SIZE))
    mask = cv2.morphologyEx(mask, cv2.MORPH_CLOSE, kernel, iterations=2)

    # Keep only the largest connected component (the main bag region)
    num_labels, labels, stats, _ = cv2.connectedComponentsWithStats(
        mask, connectivity=8)
    if num_labels > 1:
        # label 0 is background; find biggest foreground blob
        largest = 1 + np.argmax(stats[1:, cv2.CC_STAT_AREA])
        mask = np.where(labels == largest, 255, 0).astype(np.uint8)

    # Apply mask: background → black
    result = cv2.bitwise_and(img_bgr, img_bgr, mask=mask)
    return result


def preprocess(img_bgr: np.ndarray) -> np.ndarray:
    """Full pipeline: denoise → background removal → gamma correction."""
    # 1. Noise reduction
    denoised = cv2.bilateralFilter(img_bgr,
                                   BILATERAL_D,
                                   BILATERAL_SIGMA_COLOR,
                                   BILATERAL_SIGMA_SPACE)

    # 2. Background removal
    no_bg = remove_background(denoised)

    # 3. Reduce contrast enhancement (gamma roll-back)
    corrected = cv2.LUT(no_bg, GAMMA_LUT)

    return corrected


def process_split(split: str, total_stats: dict):
    img_dir = BASE_DIR / split / "images"
    images  = sorted(img_dir.glob("*.jpg"))
    n       = len(images)
    print(f"\n[{split.upper()}]  Processing {n} images …")

    for i, img_path in enumerate(images, 1):
        # ── backup original ───────────────────────────────────────────────
        rel     = img_path.relative_to(BASE_DIR)
        bak_dst = BACKUP_DIR / rel
        bak_dst.parent.mkdir(parents=True, exist_ok=True)
        if not bak_dst.exists():          # don't overwrite an existing backup
            shutil.copy2(str(img_path), str(bak_dst))

        # ── load ──────────────────────────────────────────────────────────
        img = cv2.imread(str(img_path))
        if img is None:
            print(f"  [WARN] Could not read {img_path.name}, skipping.")
            total_stats["skipped"] += 1
            continue

        # ── preprocess ────────────────────────────────────────────────────
        processed = preprocess(img)

        # ── save (overwrite original location) ───────────────────────────
        cv2.imwrite(str(img_path), processed,
                    [cv2.IMWRITE_JPEG_QUALITY, 95])

        total_stats["processed"] += 1

        if i % 500 == 0 or i == n:
            print(f"  {i}/{n} done")

    print(f"  [{split.upper()}] complete.")


def main():
    BACKUP_DIR.mkdir(exist_ok=True)

    stats = {"processed": 0, "skipped": 0}

    print("=" * 60)
    print("SIXRay Preprocessing: Denoise | BG Remove | Gamma Correct")
    print("=" * 60)
    print(f"Settings:")
    print(f"  Bilateral filter  d={BILATERAL_D}, sigmaColor={BILATERAL_SIGMA_COLOR}, sigmaSpace={BILATERAL_SIGMA_SPACE}")
    print(f"  Gamma correction  γ={GAMMA}  (>1 reduces over-brightness)")
    print(f"  Morph kernel size {MORPH_KERNEL_SIZE}px for BG removal")
    print(f"  Backup dir: {BACKUP_DIR}")

    for split in SPLITS:
        process_split(split, stats)

    print("\n" + "=" * 60)
    print(f"Done.  Processed: {stats['processed']}  |  Skipped: {stats['skipped']}")
    print(f"Originals backed up to: {BACKUP_DIR}")
    print("=" * 60)


if __name__ == "__main__":
    main()

