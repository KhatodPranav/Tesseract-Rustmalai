"""
SIXRay: Bounding Box Consistency + YOLO → COCO JSON Conversion
===============================================================
Step 1 — Bounding Box Consistency
  - Validates every YOLO label file (.txt) across train / valid / test
  - Checks:
      * class_id in [0, NUM_CLASSES-1]
      * cx, cy, w, h each in (0.0, 1.0]
      * Resulting box doesn't extend outside the image
  - Fixes:
      * Clips cx, cy, w, h to valid range
      * Drops boxes that become degenerate (w<=0 or h<=0) after clipping
      * Drops boxes with invalid class IDs
  - Overwrites fixed labels in-place; originals saved to
    sixray_v3/labels_backup/

Step 2 — COCO JSON Conversion
  Produces one JSON per split:
    sixray_v3/annotations/instances_train.json
    sixray_v3/annotations/instances_valid.json
    sixray_v3/annotations/instances_test.json

  COCO bbox format: [x_min, y_min, width, height]  (absolute pixels)
  Category IDs are 1-based:
    1=Gun  2=Knife  3=Pliers  4=Scissors  5=Wrench
"""

import cv2
import json
import shutil
import datetime
from pathlib import Path

BASE_DIR     = Path(r"C:\Users\Mayank\Downloads\archive (1)\sixray_v3")
SPLITS       = ["train", "valid", "test"]
ANNO_DIR     = BASE_DIR / "annotations"
LABEL_BACKUP = BASE_DIR / "labels_backup"

CATEGORIES = [
    {"id": 1, "name": "Gun",      "supercategory": "prohibited_item"},
    {"id": 2, "name": "Knife",    "supercategory": "prohibited_item"},
    {"id": 3, "name": "Pliers",   "supercategory": "tool"},
    {"id": 4, "name": "Scissors", "supercategory": "tool"},
    {"id": 5, "name": "Wrench",   "supercategory": "tool"},
]
NUM_CLASSES = len(CATEGORIES)   # 5


# ── helpers ───────────────────────────────────────────────────────────────────

def read_image_size(img_path: Path):
    """Return (width, height) of a JPEG without decoding all pixels."""
    img = cv2.imread(str(img_path))
    if img is None:
        return None, None
    h, w = img.shape[:2]
    return w, h


def fix_label_file(lbl_path: Path, img_w: int, img_h: int):
    """
    Read a YOLO label file, validate & fix each box, rewrite the file.
    Returns (kept, clipped, dropped) counts.
    """
    kept = clipped = dropped = 0

    if not lbl_path.exists():
        return kept, clipped, dropped

    raw_lines = lbl_path.read_text().strip().splitlines()
    fixed_lines = []

    for line in raw_lines:
        parts = line.strip().split()
        if len(parts) != 5:
            dropped += 1
            continue

        try:
            cls = int(parts[0])
            cx, cy, bw, bh = map(float, parts[1:])
        except ValueError:
            dropped += 1
            continue

        # ── class ID check ───────────────────────────────────────────────
        if cls < 0 or cls >= NUM_CLASSES:
            dropped += 1
            continue

        # ── coordinate range check + clip ────────────────────────────────
        orig = (cx, cy, bw, bh)

        # box edges in normalised coords
        x1 = cx - bw / 2
        y1 = cy - bh / 2
        x2 = cx + bw / 2
        y2 = cy + bh / 2

        # clip to [0, 1]
        x1 = max(0.0, min(1.0, x1))
        y1 = max(0.0, min(1.0, y1))
        x2 = max(0.0, min(1.0, x2))
        y2 = max(0.0, min(1.0, y2))

        new_bw = x2 - x1
        new_bh = y2 - y1

        if new_bw <= 0 or new_bh <= 0:
            dropped += 1
            continue

        new_cx = x1 + new_bw / 2
        new_cy = y1 + new_bh / 2

        was_clipped = (new_cx, new_cy, new_bw, new_bh) != orig
        if was_clipped:
            clipped += 1
        else:
            kept += 1

        fixed_lines.append(f"{cls} {new_cx:.6f} {new_cy:.6f} {new_bw:.6f} {new_bh:.6f}")

    lbl_path.write_text("\n".join(fixed_lines) + ("\n" if fixed_lines else ""))
    return kept, clipped, dropped


def yolo_to_coco_bbox(cx, cy, bw, bh, img_w, img_h):
    """Convert normalised YOLO cx,cy,w,h → COCO absolute x_min,y_min,w,h."""
    abs_w  = bw * img_w
    abs_h  = bh * img_h
    x_min  = (cx - bw / 2) * img_w
    y_min  = (cy - bh / 2) * img_h
    # clamp to image
    x_min  = max(0.0, x_min)
    y_min  = max(0.0, y_min)
    abs_w  = min(abs_w, img_w - x_min)
    abs_h  = min(abs_h, img_h - y_min)
    return round(x_min, 2), round(y_min, 2), round(abs_w, 2), round(abs_h, 2)


# ── main ──────────────────────────────────────────────────────────────────────

def process_split(split: str, img_id_start: int, ann_id_start: int):
    """
    Fix labels and build COCO JSON for one split.
    Returns (coco_dict, next_img_id, next_ann_id, stats).
    """
    img_dir = BASE_DIR / split / "images"
    lbl_dir = BASE_DIR / split / "labels"

    images_list      = []
    annotations_list = []
    img_id   = img_id_start
    ann_id   = ann_id_start

    total_kept = total_clipped = total_dropped = total_imgs = 0
    no_label   = 0

    image_files = sorted(img_dir.glob("*.jpg"))

    print(f"\n[{split.upper()}]  {len(image_files)} images")

    for img_path in image_files:
        img_w, img_h = read_image_size(img_path)
        if img_w is None:
            print(f"  [WARN] Unreadable image: {img_path.name}")
            continue

        total_imgs += 1

        # ── backup + fix label ───────────────────────────────────────────
        lbl_path = lbl_dir / (img_path.stem + ".txt")
        bak_lbl  = LABEL_BACKUP / split / "labels" / lbl_path.name

        if lbl_path.exists():
            bak_lbl.parent.mkdir(parents=True, exist_ok=True)
            if not bak_lbl.exists():
                shutil.copy2(str(lbl_path), str(bak_lbl))
            k, c, d = fix_label_file(lbl_path, img_w, img_h)
            total_kept    += k
            total_clipped += c
            total_dropped += d
        else:
            no_label += 1

        # ── COCO images entry ────────────────────────────────────────────
        images_list.append({
            "id":        img_id,
            "file_name": img_path.name,
            "width":     img_w,
            "height":    img_h,
        })

        # ── COCO annotations from (fixed) label ──────────────────────────
        if lbl_path.exists():
            for line in lbl_path.read_text().strip().splitlines():
                parts = line.strip().split()
                if len(parts) != 5:
                    continue
                cls = int(parts[0])
                cx, cy, bw, bh = map(float, parts[1:])

                x_min, y_min, abs_w, abs_h = yolo_to_coco_bbox(
                    cx, cy, bw, bh, img_w, img_h)

                if abs_w <= 0 or abs_h <= 0:
                    continue

                annotations_list.append({
                    "id":          ann_id,
                    "image_id":    img_id,
                    "category_id": cls + 1,   # 1-based
                    "bbox":        [x_min, y_min, abs_w, abs_h],
                    "area":        round(abs_w * abs_h, 2),
                    "iscrowd":     0,
                    "segmentation": [],
                })
                ann_id += 1

        img_id += 1

    stats = {
        "images":       total_imgs,
        "annotations":  len(annotations_list),
        "kept":         total_kept,
        "clipped":      total_clipped,
        "dropped":      total_dropped,
        "no_label":     no_label,
    }

    coco = {
        "info": {
            "description":  f"SIXRay v3 — {split} split",
            "version":      "1.0",
            "year":         2024,
            "date_created": datetime.datetime.utcnow().isoformat(),
        },
        "licenses":    [],
        "categories":  CATEGORIES,
        "images":      images_list,
        "annotations": annotations_list,
    }

    return coco, img_id, ann_id, stats


def main():
    ANNO_DIR.mkdir(exist_ok=True)
    LABEL_BACKUP.mkdir(exist_ok=True)

    print("=" * 60)
    print("SIXRay: BBox Consistency Check + YOLO → COCO JSON")
    print("=" * 60)

    img_id = 1
    ann_id = 1
    grand  = {"images": 0, "annotations": 0, "kept": 0,
              "clipped": 0, "dropped": 0, "no_label": 0}

    for split in SPLITS:
        coco, img_id, ann_id, stats = process_split(split, img_id, ann_id)

        out_path = ANNO_DIR / f"instances_{split}.json"
        with open(out_path, "w") as f:
            json.dump(coco, f, indent=2)

        for k in grand:
            grand[k] += stats[k]

        print(f"  Images      : {stats['images']}")
        print(f"  Annotations : {stats['annotations']}")
        print(f"  Boxes kept  : {stats['kept']}")
        print(f"  Boxes clipped (fixed): {stats['clipped']}")
        print(f"  Boxes dropped (invalid): {stats['dropped']}")
        print(f"  Images with no label: {stats['no_label']}")
        print(f"  → Saved: {out_path.name}")

    print("\n" + "=" * 60)
    print("GRAND TOTAL")
    print(f"  Images      : {grand['images']}")
    print(f"  Annotations : {grand['annotations']}")
    print(f"  Boxes kept  : {grand['kept']}")
    print(f"  Boxes clipped (fixed): {grand['clipped']}")
    print(f"  Boxes dropped: {grand['dropped']}")
    print(f"  Annotations dir: {ANNO_DIR}")
    print(f"  Label backup  : {LABEL_BACKUP}")
    print("=" * 60)


if __name__ == "__main__":
    main()

